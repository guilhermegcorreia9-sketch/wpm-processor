# -*- coding: utf-8 -*-
import os
import math
from datetime import datetime

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsSettings,
    QgsWkbTypes,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
)
from qgis.core import QgsRasterLayer, QgsProject
from qgis.gui import QgsFileWidget
from qgis.PyQt import QtCore
from qgis.PyQt.QtCore import Qt, QDate
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QPushButton,
    QTabWidget,
    QWidget,
    QRadioButton,
    QButtonGroup,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QDateEdit,
    QSpinBox,
    QDoubleSpinBox,
    QComboBox,
    QCheckBox,
    QPlainTextEdit,
    QProgressBar,
    QMessageBox,
    QSizePolicy,
    QFrame,
    QScrollArea,
)

from .tasks import CbersWpmTask
from .roi_tool import RoiDrawTool

PLUGIN_DIR = os.path.dirname(__file__)


STYLE_SHEET = """
QDialog {
    background-color: #fcfcfd;
    font-size: 12px;
}
QTabWidget::pane {
    border: none;
    border-top: 1px solid #edeef1;
    background: #fcfcfd;
}
QScrollArea#roiScroll {
    background: #fcfcfd;
    border: none;
}
QScrollArea#roiScroll > QWidget > QWidget {
    background: #fcfcfd;
}
QTabBar {
    qproperty-drawBase: 0;
}
QTabBar::tab {
    background: transparent;
    color: #9a9fa6;
    padding: 8px 12px;
    margin-right: 6px;
    border: none;
    border-bottom: 2px solid transparent;
    font-weight: 600;
    min-height: 24px;
    min-width: 90px;
}
QTabBar::tab:hover {
    color: #55595f;
}
QTabBar::tab:selected {
    color: #2c2f33;
    border-bottom: 2px solid #6fb897;
}
QGroupBox {
    font-weight: 600;
    color: #2c2f33;
    border: none;
    border-top: 1px solid #eef0f2;
    border-radius: 0px;
    margin-top: 18px;
    padding: 16px 2px 4px 2px;
    background-color: transparent;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 0px;
    top: 6px;
    padding: 0 2px;
    color: #4f9c7c;
    font-size: 11px;
    letter-spacing: 0.5px;
}
QLabel {
    color: #3c4046;
}
QLabel[hint="true"] {
    color: #a6abb2;
    font-size: 10.5px;
}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QDateEdit, QPlainTextEdit, QTableWidget {
    border: 1px solid #e6e8eb;
    border-radius: 6px;
    padding: 5px 8px;
    background: #ffffff;
    color: #2c2f33;
    selection-background-color: #cdeade;
    selection-color: #1f5c42;
}
QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, QComboBox:hover, QDateEdit:hover {
    border: 1px solid #d7dbdf;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus, QDateEdit:focus {
    border: 1px solid #8fcdae;
    background: #ffffff;
}
QTableWidget {
    gridline-color: #f0f1f3;
}
QHeaderView::section {
    background-color: #fafbfb;
    color: #9a9fa6;
    border: none;
    border-bottom: 1px solid #edeef1;
    padding: 6px;
    font-weight: 600;
    font-size: 10.5px;
}
QComboBox::drop-down, QDateEdit::drop-down {
    border: none;
    width: 20px;
}
QPushButton {
    background-color: #ffffff;
    border: 1px solid #e2e5e8;
    border-radius: 6px;
    padding: 7px 14px;
    color: #4a4f56;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #f5f6f7;
    border: 1px solid #d7dbdf;
}
QPushButton#runButton {
    background-color: #6fb897;
    color: #ffffff;
    font-weight: 600;
    border: none;
    padding: 9px 24px;
    font-size: 12.5px;
    border-radius: 7px;
}
QPushButton#runButton:hover {
    background-color: #5fa686;
}
QPushButton#runButton:disabled {
    background-color: #d7ebe1;
    color: #ffffff;
}
QPushButton#cancelButton {
    background-color: #ffffff;
    color: #d98a7d;
    border: 1px solid #f0d9d4;
    padding: 9px 18px;
    border-radius: 7px;
    font-weight: 600;
}
QPushButton#cancelButton:hover {
    background-color: #fdf3f1;
}
QPushButton#cancelButton:disabled {
    background-color: #ffffff;
    color: #e5cec8;
    border: 1px solid #f5eae7;
}
QPushButton#drawButton {
    background-color: #eef4fc;
    color: #5b84d6;
    border: 1px solid #dde8f9;
    font-weight: 600;
}
QPushButton#drawButton:hover {
    background-color: #e2ecfb;
}
QProgressBar {
    border: none;
    border-radius: 3px;
    background: #eef0f2;
    height: 6px;
    text-align: center;
    color: transparent;
}
QProgressBar::chunk {
    background-color: #6fb897;
    border-radius: 3px;
}
QPlainTextEdit#logBox {
    background-color: #fafbfb;
    color: #4a4f56;
    font-family: Consolas, "Courier New", monospace;
    font-size: 10.5px;
    border: 1px solid #edeef1;
    border-radius: 6px;
}
QRadioButton {
    color: #3c4046;
    font-weight: 500;
    padding: 4px;
    spacing: 8px;
}
QCheckBox {
    color: #3c4046;
    spacing: 8px;
}
QFrame#headerFrame {
    background-color: transparent;
    border-bottom: 1px solid #eef0f2;
}
QLabel#headerTitle {
    color: #2c2f33;
    font-size: 17px;
    font-weight: 700;
}
QLabel#headerSubtitle {
    color: #9a9fa6;
    font-size: 11px;
}
"""


class CbersWpmDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.canvas = iface.mapCanvas() if iface else None
        self.task = None
        self.draw_tool = None
        self.previous_map_tool = None

        self.setWindowTitle("CBERS-4A WPM Processor")
        icon_path = os.path.join(PLUGIN_DIR, "icons", "icon.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        self.resize(900, 820)
        self.setMinimumSize(820, 760)
        self.setStyleSheet(STYLE_SHEET)

        self._build_ui()
        self._load_settings()

    # ------------------------------------------------------------------ #
    # Construção da interface
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(14)
        root.setContentsMargins(20, 18, 20, 18)

        # Cabeçalho
        header = QFrame()
        header.setObjectName("headerFrame")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(2, 4, 2, 16)
        header_layout.setSpacing(12)

        icon_label = QLabel()
        icon_path = os.path.join(PLUGIN_DIR, "icons", "icon.png")
        icon_pixmap = QIcon(icon_path).pixmap(40, 40)
        if not icon_pixmap.isNull():
            icon_label.setPixmap(icon_pixmap)
        icon_label.setFixedSize(40, 40)
        icon_label.setScaledContents(True)
        header_layout.addWidget(icon_label, alignment=Qt.AlignTop)

        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(2)
        title = QLabel("CBERS-4A WPM Processor")
        title.setObjectName("headerTitle")
        subtitle = QLabel("Geração de imagens de alta resolução espacial do satélite CBERS-4A WPM, a partir do SpatioTemporal Asset Catalog (STAC) do projeto Brazil Data Cube (INPE)")
        subtitle.setObjectName("headerSubtitle")
        text_layout.addWidget(title)
        text_layout.addWidget(subtitle)
        header_layout.addLayout(text_layout, stretch=1)

        root.addWidget(header)

        self.tabs = QTabWidget()
        self.tabs.tabBar().setMinimumHeight(40)
        root.addWidget(self.tabs, stretch=1)

        roi_scroll = QScrollArea()
        roi_scroll.setObjectName("roiScroll")
        roi_scroll.setWidgetResizable(True)
        roi_scroll.setFrameShape(QFrame.NoFrame)
        roi_tab_content = self._build_roi_tab()
        roi_scroll.setWidget(roi_tab_content)
        self.tabs.addTab(roi_scroll, "ROI")
        self.tabs.addTab(self._build_search_tab(), "Processamento")
        self.tabs.addTab(self._build_output_tab(), "Produto Final")
        self.tabs.addTab(self._build_log_tab(), "Execução")

        # Rodapé: progresso + botões
        footer = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setVisible(False)
        footer.addWidget(self.progress_bar, stretch=1)

        self.cancel_button = QPushButton("Cancelar")
        self.cancel_button.setObjectName("cancelButton")
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.cancel_processing)
        footer.addWidget(self.cancel_button)

        self.run_button = QPushButton("▶  Executar processamento")
        self.run_button.setObjectName("runButton")
        self.run_button.clicked.connect(self.run_processing)
        footer.addWidget(self.run_button)

        root.addLayout(footer)

    # -- Aba 1: ROI ------------------------------------------------------
    def _build_roi_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(2, 4, 2, 4)

        group = QGroupBox("Origem da Área de Interesse (ROI)")
        group.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        glayout = QVBoxLayout(group)

        self.roi_source_group = QButtonGroup(self)
        self.radio_roi_file = QRadioButton("Arquivo vetorial (Shapefile / GeoPackage)")
        self.radio_roi_single_coord = QRadioButton("Coordenada pontual (Buffer Bounding-Box)")
        self.radio_roi_coords = QRadioButton("Desenhar no mapa ou digitar polígono (coordenadas)")

        for rb in (self.radio_roi_file, self.radio_roi_single_coord, self.radio_roi_coords):
            rb.setStyleSheet("QRadioButton { font-weight: normal; }")
        self.radio_roi_file.setChecked(True)
        for i, rb in enumerate([self.radio_roi_file, self.radio_roi_single_coord, self.radio_roi_coords]):
            self.roi_source_group.addButton(rb, i)
            glayout.addWidget(rb)

        self.roi_stack = QStackedWidget()
        self.roi_stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.roi_stack.setMinimumHeight(260)
        glayout.addWidget(self.roi_stack)

        # Página 0: arquivo
        file_page = QWidget()
        file_layout = QFormLayout(file_page)
        self.roi_file_widget = QgsFileWidget()
        self.roi_file_widget.setStorageMode(QgsFileWidget.GetFile)
        self.roi_file_widget.setFilter("Vetores (*.gpkg *.shp);;GeoPackage (*.gpkg);;Shapefile (*.shp)")
        file_layout.addRow("Arquivo do ROI:", self.roi_file_widget)
        self.roi_stack.addWidget(file_page)

        # Página 1: Coordenada pontual com Buffer Bounding Box
        single_coord_page = QWidget()
        single_coord_layout = QFormLayout(single_coord_page)

        self.single_lon_edit = QLineEdit()
        self.single_lon_edit.setPlaceholderText("-47.8825")
        single_coord_layout.addRow("Longitude (lon - WGS84):", self.single_lon_edit)

        self.single_lat_edit = QLineEdit()
        self.single_lat_edit.setPlaceholderText("-15.7942")
        single_coord_layout.addRow("Latitude (lat - WGS84):", self.single_lat_edit)

        self.buffer_distance_spin = QDoubleSpinBox()
        self.buffer_distance_spin.setRange(0.1, 500.0)
        self.buffer_distance_spin.setValue(10.0)
        self.buffer_distance_spin.setSuffix(" km")
        single_coord_layout.addRow("Distância do Buffer:", self.buffer_distance_spin)

        coord_hint = QLabel("Será criado um bounding-box quadrado delimitado por esse raio de distância em torno da coordenada informada.")
        coord_hint.setProperty("hint", "true")
        coord_hint.setWordWrap(True)
        single_coord_layout.addRow("", coord_hint)
        self.roi_stack.addWidget(single_coord_page)

        # Página 2: coordenadas manuais de polígono / desenho
        coords_page = QWidget()
        coords_layout = QVBoxLayout(coords_page)

        draw_row = QHBoxLayout()
        self.draw_button = QPushButton("✚ Desenhar polígono no mapa")
        self.draw_button.setObjectName("drawButton")
        self.draw_button.clicked.connect(self._start_draw_roi)
        draw_row.addWidget(self.draw_button)
        draw_hint = QLabel("Clique para adicionar vértices; clique com o botão direito (ou Enter) para concluir.")
        draw_hint.setProperty("hint", "true")
        draw_hint.setWordWrap(True)
        draw_row.addWidget(draw_hint, stretch=1)
        coords_layout.addLayout(draw_row)

        self.coords_table = QTableWidget(0, 2)
        self.coords_table.setHorizontalHeaderLabels(["Longitude (lon)", "Latitude (lat)"])
        self.coords_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.coords_table.setMinimumHeight(160)
        coords_layout.addWidget(self.coords_table)

        table_buttons = QHBoxLayout()
        add_row_btn = QPushButton("+ Adicionar vértice")
        add_row_btn.clicked.connect(self._add_coord_row)
        remove_row_btn = QPushButton("− Remover selecionado")
        remove_row_btn.clicked.connect(self._remove_coord_row)
        clear_btn = QPushButton("Limpar tudo")
        clear_btn.clicked.connect(lambda: self.coords_table.setRowCount(0))
        table_buttons.addWidget(add_row_btn)
        table_buttons.addWidget(remove_row_btn)
        table_buttons.addWidget(clear_btn)
        table_buttons.addStretch(1)
        coords_layout.addLayout(table_buttons)

        coords_hint = QLabel("As coordenadas devem estar em graus decimais, sistema WGS84 (EPSG:4326), com pelo menos 3 vértices.")
        coords_hint.setProperty("hint", "true")
        coords_hint.setWordWrap(True)
        coords_layout.addWidget(coords_hint)

        self.roi_stack.addWidget(coords_page)

        layout.addWidget(group, stretch=1)

        self.radio_roi_file.toggled.connect(lambda c: c and self.roi_stack.setCurrentIndex(0))
        self.radio_roi_single_coord.toggled.connect(lambda c: c and self.roi_stack.setCurrentIndex(1))
        self.radio_roi_coords.toggled.connect(lambda c: c and self.roi_stack.setCurrentIndex(2))

        return widget

    # -- Aba 2: busca e processamento ------------------------------------
    def _build_search_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        search_group = QGroupBox("Parâmetros de Busca da Cena")
        search_form = QFormLayout(search_group)
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd/MM/yyyy")
        self.date_edit.setDate(QDate.currentDate())
        search_form.addRow("Data alvo de aquisição:", self.date_edit)
        date_hint = QLabel("O plugin busca automaticamente a cena mais próxima desta data que intersecte o ROI")
        date_hint.setProperty("hint", "true")
        date_hint.setWordWrap(True)
        search_form.addRow("", date_hint)
        layout.addWidget(search_group)

        tclt_group = QGroupBox("Processamento TCLT (fusão / registro / PCA)")
        tclt_form = QFormLayout(tclt_group)

        self.tclt_exe_widget = QgsFileWidget()
        self.tclt_exe_widget.setStorageMode(QgsFileWidget.GetFile)
        self.tclt_exe_widget.setFilter("Executável (*.exe)")
        tclt_form.addRow("Executável tclt_exe.exe:", self.tclt_exe_widget)

        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(1, 128)
        self.threads_spin.setValue(1)
        tclt_form.addRow("Número de threads:", self.threads_spin)

        layout.addWidget(tclt_group)
        layout.addStretch(1)
        return widget

    # -- Aba 3: produto final --------------------------------------------
    def _build_output_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        type_group = QGroupBox("Produtos a Serem Gerados e Carregados")
        type_form = QFormLayout(type_group)

        self.gen_rgb_check = QCheckBox("Visualização RGB (PCA / Fusão Pancromática)")
        self.gen_rgb_check.setChecked(True)
        self.gen_ngb_check = QCheckBox("Banda Bruta NGB (NIR / Green / Blue)")
        self.gen_ngb_check.setChecked(False)

        type_form.addRow(self.gen_rgb_check)
        type_form.addRow(self.gen_ngb_check)

        prod_hint = QLabel("Selecione quais produtos deseja processar e carregar automaticamente no painel do QGIS.")
        prod_hint.setProperty("hint", "true")
        prod_hint.setWordWrap(True)
        type_form.addRow("", prod_hint)
        layout.addWidget(type_group)

        out_group = QGroupBox("Pasta e Contraste")
        out_form = QFormLayout(out_group)
        self.output_dir_widget = QgsFileWidget()
        self.output_dir_widget.setStorageMode(QgsFileWidget.GetDirectory)
        out_form.addRow("Pasta de saída:", self.output_dir_widget)

        self.contrast_combo = QComboBox()
        self.contrast_combo.addItems(["600", "800"])
        out_form.addRow("Realce de contraste RGB:", self.contrast_combo)
        contrast_hint = QLabel("Define qual realce linear de contraste (raiz quadrada) é mantido no produto RGB final.")
        contrast_hint.setProperty("hint", "true")
        contrast_hint.setWordWrap(True)
        out_form.addRow("", contrast_hint)
        layout.addWidget(out_group)

        format_group = QGroupBox("Formato de Saída")
        format_form = QFormLayout(format_group)

        format_row = QHBoxLayout()
        self.radio_format_group = QButtonGroup(self)
        self.radio_tiff = QRadioButton("GeoTIFF")
        self.radio_jp2 = QRadioButton("JPEG2000 (JP2)")
        self.radio_jp2.setChecked(True)
        self.radio_format_group.addButton(self.radio_tiff, 0)
        self.radio_format_group.addButton(self.radio_jp2, 1)
        format_row.addWidget(self.radio_tiff)
        format_row.addWidget(self.radio_jp2)
        format_row.addStretch(1)
        format_form.addRow("Formato de saída:", format_row)

        self.lossless_check = QCheckBox("Sem perdas (lossless)")
        self.jp2_quality_spin = QSpinBox()
        self.jp2_quality_spin.setRange(1, 100)
        self.jp2_quality_spin.setValue(100)
        jp2_row = QHBoxLayout()
        jp2_row.addWidget(self.lossless_check)
        jp2_row.addSpacing(20)
        jp2_row.addWidget(QLabel("Qualidade JP2:"))
        jp2_row.addWidget(self.jp2_quality_spin)
        jp2_row.addStretch(1)
        format_form.addRow("", jp2_row)

        self.radio_jp2.toggled.connect(self._update_format_controls)
        self.lossless_check.toggled.connect(self._update_format_controls)

        layout.addWidget(format_group)
        layout.addStretch(1)

        self._update_format_controls()
        return widget

    def _update_format_controls(self):
        is_jp2 = self.radio_jp2.isChecked()
        self.lossless_check.setEnabled(is_jp2)
        self.jp2_quality_spin.setEnabled(is_jp2 and not self.lossless_check.isChecked())

    # -- Aba 4: log --------------------------------------------------------
    def _build_log_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.log_box = QPlainTextEdit()
        self.log_box.setObjectName("logBox")
        self.log_box.setReadOnly(True)
        layout.addWidget(self.log_box)
        clear_btn = QPushButton("Limpar log")
        clear_btn.clicked.connect(self.log_box.clear)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(clear_btn)
        layout.addLayout(row)
        return widget

    # ------------------------------------------------------------------ #
    # ROI: tabela de coordenadas e ferramenta de desenho
    # ------------------------------------------------------------------ #
    def _add_coord_row(self, lon=0.0, lat=0.0):
        row = self.coords_table.rowCount()
        self.coords_table.insertRow(row)
        self.coords_table.setItem(row, 0, QTableWidgetItem(str(lon)))
        self.coords_table.setItem(row, 1, QTableWidgetItem(str(lat)))

    def _remove_coord_row(self):
        rows = sorted({idx.row() for idx in self.coords_table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.coords_table.removeRow(r)

    def _start_draw_roi(self):
        if self.canvas is None:
            QMessageBox.warning(self, "Indisponível", "Nenhum mapa disponível para desenhar o ROI.")
            return
        self.previous_map_tool = self.canvas.mapTool()
        self.draw_tool = RoiDrawTool(self.canvas)
        self.draw_tool.finished.connect(self._on_roi_drawn)
        self.draw_tool.cancelled.connect(self._on_roi_draw_cancelled)
        self.canvas.setMapTool(self.draw_tool)
        self.showMinimized()
        if self.iface:
            self.iface.messageBar().pushMessage(
                "CBERS-4A WPM",
                "Clique no mapa para desenhar o ROI. Botão direito ou Enter para concluir.",
                level=Qgis.Info, duration=6)

    def _restore_map_tool(self):
        if self.canvas is not None:
            self.canvas.setMapTool(self.previous_map_tool)
        self.draw_tool = None
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _on_roi_drawn(self, coords):
        self.coords_table.setRowCount(0)
        for lon, lat in coords:
            self._add_coord_row(round(lon, 6), round(lat, 6))
        self._restore_map_tool()
        if self.iface:
            self.iface.messageBar().pushMessage(
                "CBERS-4A WPM", "ROI desenhado com {} vértices.".format(len(coords)),
                level=Qgis.Success, duration=4)

    def _on_roi_draw_cancelled(self):
        self._restore_map_tool()

    def _build_bounding_box_coords(self, lon, lat, dist_km):
        """Calcula um bounding-box quadrado de dist_km ao redor da coordenada."""
        lat_deg = dist_km / 111.0
        lon_deg = dist_km / (111.0 * math.cos(math.radians(lat)))

        min_lon = lon - lon_deg
        max_lon = lon + lon_deg
        min_lat = lat - lat_deg
        max_lat = lat + lat_deg

        # Retorna o polígono quadrado fechado (4 cantos)
        return [
            (min_lon, min_lat),
            (max_lon, min_lat),
            (max_lon, max_lat),
            (min_lon, max_lat),
            (min_lon, min_lat)
        ]

    # ------------------------------------------------------------------ #
    # Coleta e validação dos parâmetros
    # ------------------------------------------------------------------ #
    def _collect_params(self):
        params = {}

        if not self.gen_rgb_check.isChecked() and not self.gen_ngb_check.isChecked():
            raise ValueError("Selecione pelo menos um produto para gerar (RGB e/ou NGB).")

        params["generate_rgb"] = self.gen_rgb_check.isChecked()
        params["generate_ngb"] = self.gen_ngb_check.isChecked()

        if self.radio_roi_file.isChecked():
            path = self.roi_file_widget.filePath()
            if not path:
                raise ValueError("Selecione um arquivo de ROI (Shapefile ou GeoPackage).")
            params["roi_shapefile"] = path
            params["roi_coordinates"] = None

        elif self.radio_roi_single_coord.isChecked():
            lon_str = self.single_lon_edit.text().strip().replace(",", ".")
            lat_str = self.single_lat_edit.text().strip().replace(",", ".")
            if not lon_str or not lat_str:
                raise ValueError("Informe os valores de Longitude e Latitude.")
            try:
                lon = float(lon_str)
                lat = float(lat_str)
            except ValueError:
                raise ValueError("Longitude ou Latitude inválida.")

            dist_km = self.buffer_distance_spin.value()
            params["roi_shapefile"] = None
            params["roi_coordinates"] = self._build_bounding_box_coords(lon, lat, dist_km)

        else:
            coords = []
            for row in range(self.coords_table.rowCount()):
                lon_item = self.coords_table.item(row, 0)
                lat_item = self.coords_table.item(row, 1)
                if lon_item is None or lat_item is None:
                    continue
                try:
                    lon = float(lon_item.text().replace(",", "."))
                    lat = float(lat_item.text().replace(",", "."))
                except ValueError:
                    raise ValueError("Coordenada inválida na linha {}.".format(row + 1))
                coords.append((lon, lat))
            if len(coords) < 3:
                raise ValueError("Desenhe ou digite pelo menos 3 vértices para o ROI.")
            params["roi_shapefile"] = None
            params["roi_coordinates"] = coords

        params["target_date"] = self.date_edit.date().toString("yyyy-MM-dd")

        tclt_exe = self.tclt_exe_widget.filePath()
        if not tclt_exe:
            raise ValueError("Informe o caminho do executável tclt_exe.exe.")
        params["tclt_exe"] = tclt_exe
        params["threads"] = self.threads_spin.value()

        output_dir = self.output_dir_widget.filePath()
        if not output_dir:
            raise ValueError("Informe a pasta de saída dos produtos finais.")
        params["final_output_dir"] = output_dir
        params["contrast_stretch"] = int(self.contrast_combo.currentText())

        params["output_format"] = "JP2" if self.radio_jp2.isChecked() else "TIFF"
        params["lossless"] = self.lossless_check.isChecked()
        params["jp2_quality"] = self.jp2_quality_spin.value()
        params["output_crs"] = None

        return params

    # ------------------------------------------------------------------ #
    # Execução
    # ------------------------------------------------------------------ #
    def run_processing(self):
        try:
            params = self._collect_params()
        except ValueError as exc:
            QMessageBox.warning(self, "Parâmetros incompletos", str(exc))
            return

        self._save_settings()
        self.tabs.setCurrentIndex(3)
        self.log_box.clear()
        self._append_log("Iniciando processamento...")

        self.run_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.progress_bar.setVisible(True)

        self.task = CbersWpmTask("CBERS-4A WPM Processor", params)
        self.task.messageLogged.connect(self._append_log)
        self.task.taskCompleted.connect(self._on_task_finished_ok)
        self.task.taskTerminated.connect(self._on_task_finished_error)
        QgsApplication.taskManager().addTask(self.task)

    def cancel_processing(self):
        if self.task is not None:
            self.task.cancel()
            self._append_log("Cancelamento solicitado — aguardando o TCLT encerrar...")
            self.cancel_button.setEnabled(False)

    def _on_task_finished_ok(self):
        self._append_log("Processamento concluído com sucesso.")
        outputs = self.task.outputs or []
        if outputs:
            self._append_log("Produtos gerados:")
            for p in outputs:
                self._append_log("  • {}".format(p))
            self._load_outputs_into_qgis(outputs)
        self._reset_run_state()
        QMessageBox.information(
            self, "Concluído",
            "Processamento concluído com sucesso.\n\n{} produto(s) gerado(s) em:\n{}".format(
                len(outputs), self.output_dir_widget.filePath())
        )

    def _load_outputs_into_qgis(self, output_paths):
        """Carrega automaticamente os produtos selecionados (.tif/.jp2) no painel
        de Camadas do QGIS."""
        project = QgsProject.instance()
        for path in output_paths:
            if not path or not os.path.exists(path):
                self._append_log("Aviso: produto não encontrado para carregar: {}".format(path))
                continue
            layer_name = os.path.splitext(os.path.basename(path))[0]
            layer = QgsRasterLayer(path, layer_name)
            if not layer.isValid():
                self._append_log("Aviso: não foi possível carregar a camada '{}' no QGIS.".format(layer_name))
                continue
            project.addMapLayer(layer)
            self._append_log("Camada adicionada ao projeto: {}".format(layer_name))
        if self.canvas is not None:
            self.canvas.refresh()

    def _on_task_finished_error(self):
        msg = self.task.error_message or "O processamento foi interrompido."
        was_user_cancel = self.task.exception is None and "cancelad" in msg.lower()
        self._append_log("ERRO: {}".format(msg) if not was_user_cancel else "Processamento cancelado.")
        self._reset_run_state()
        if not was_user_cancel:
            QMessageBox.critical(self, "Erro no processamento", msg)

    def _reset_run_state(self):
        self.run_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.task = None

    def _append_log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_box.appendPlainText("[{}] {}".format(timestamp, message))

    # ------------------------------------------------------------------ #
    # Persistência de configurações entre sessões
    # ------------------------------------------------------------------ #
    def _load_settings(self):
        s = QgsSettings()
        self.tclt_exe_widget.setFilePath(s.value("cbers_wpm/tclt_exe", "", type=str))
        self.output_dir_widget.setFilePath(s.value("cbers_wpm/output_dir", "", type=str))
        self.threads_spin.setValue(int(s.value("cbers_wpm/threads", 1)))

    def _save_settings(self):
        s = QgsSettings()
        s.setValue("cbers_wpm/tclt_exe", self.tclt_exe_widget.filePath())
        s.setValue("cbers_wpm/output_dir", self.output_dir_widget.filePath())
        s.setValue("cbers_wpm/threads", self.threads_spin.value())

    def closeEvent(self, event):
        if self.task is not None and self.task.isActive():
            reply = QMessageBox.question(
                self, "Processamento em andamento",
                "Um processamento ainda está em execução. Deseja cancelá-lo e fechar?",
                QMessageBox.Yes | QMessageBox.No)
            if reply != QMessageBox.Yes:
                event.ignore()
                return
            self.task.cancel()
        if self.draw_tool is not None:
            self._restore_map_tool()
        super().closeEvent(event)