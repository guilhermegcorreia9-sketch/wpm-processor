# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .cbers_wpm_dialog import CbersWpmDialog

PLUGIN_DIR = os.path.dirname(__file__)


class CbersWpmPlugin:
    """Ponto de entrada do plugin, exigido pelo QGIS (classFactory)."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(PLUGIN_DIR, "icons", "icon.png")
        self.action = QAction(QIcon(icon_path), "CBERS-4A/WPM Processor", self.iface.mainWindow())
        self.action.setWhatsThis("Gera imagens RGB de alta resolução espacial")
        self.action.setStatusTip("Abrir o CBERS-4A/WPM Processor")
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu("&CBERS-4A/WPM Processor", self.action)

    def unload(self):
        self.iface.removePluginRasterMenu("&CBERS-4A/WPM Processor", self.action)
        self.iface.removeToolBarIcon(self.action)
        self.action = None
        self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = CbersWpmDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
