# -*- coding: utf-8 -*-
# Created by Miguel Alexandre da Cunha
import os, re, glob, shutil, tempfile, subprocess, gc, threading
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET

import numpy as np
import requests

# QGIS runs run_pipeline() inside a QgsTask on a background thread. pyproj lazily
# opens PROJ's sqlite database on first use, and doing that for the first time from
# a worker thread while QGIS's own (separately loaded) PROJ is active on the main
# thread can race and crash the whole process ("access violation" in proj_create /
# DatabaseContext). Forcing a single, lock-protected global context avoids the race.
import pyproj
pyproj.set_use_global_context(True)

import geopandas as gpd
import rasterio
from rasterio.io import MemoryFile
from rasterio.mask import mask as rio_mask
from rasterio.merge import merge as rio_merge
from rasterio.fill import fillnodata
from rasterio import Affine
from rasterio.warp import calculate_default_transform, reproject, Resampling
from rasterio.transform import array_bounds
from shapely.geometry import mapping, box


class PipelineError(Exception):
    """Erro esperado/tratado durante o processamento (mensagem já é amigável)."""
    pass


class PipelineCancelled(Exception):
    """Levantada quando o usuário cancela o processamento em andamento."""
    pass


# Trava global que serializa toda construção/transformação de CRS via pyproj
# (geopandas GeoDataFrame(crs=...), .to_crs(), .estimate_utm_crs()) feita por
# este módulo. O QGIS usa PROJ continuamente na main thread (renderização,
# exibição de coordenadas), e o processamento roda em uma QgsTask em segundo
# plano - acesso concorrente ao PROJ entre threads já causou access violation
# (ver histórico no cbers_wpm_dialog.py). Esta trava não impede o próprio QGIS
# de usar PROJ na main thread (isso está fora do nosso controle), mas garante
# que ESTE módulo nunca dispare duas operações de PROJ ao mesmo tempo entre si,
# e mantém cada seção crítica curta para minimizar a janela de corrida.
_PROJ_LOCK = threading.Lock()


# Small "context" buffer applied to every ROI below (any input method) - clamped
# to this range to avoid accidentally requesting/processing an enormous area.
MIN_BUFFER_KM = 0.002   # 2 m
MAX_BUFFER_KM = 10.0    # 10 km

# Point -> bounding-box buffer offered in the dialog's "single coordinate" ROI
# mode. The resulting box is (2 * POINT_BUFFER_KM) on each side, so this is
# clamped to whole kilometers from 2 to 10 -> a 2x2 km up to a 10x10 km box.
POINT_BUFFER_MIN_KM = 2
POINT_BUFFER_MAX_KM = 10

STAC_URL   = "https://data.inpe.br/bdc/stac/v1/"
COLLECTION = "CB4A-WPM-L4-DN-1"

# CBERS-4A WPM item ids embed the path/row tile id as e.g. "..._213_127_...".
_TILE_RE = re.compile(r'(\d{3}_\d{3})')


def _clamp_buffer_km(value, default=2.0):
    try:
        value = float(value)
    except (TypeError, ValueError):
        value = default
    return min(max(value, MIN_BUFFER_KM), MAX_BUFFER_KM)


def _extract_tile(item):
    m = _TILE_RE.search(item["id"])
    return m.group(1) if m else None


def _item_date_str(item):
    dt_str = item["properties"].get("datetime") or item["properties"].get("start_datetime")
    return dt_str[:10] if dt_str else None


def _get_thumbnail_href(item):
    """BDC/STAC items normally carry a `thumbnail` asset (a .png quicklook of the
    scene). Fall back to any asset that looks like a thumbnail/preview image in
    case the collection names it differently."""
    assets = item.get("assets", {}) or {}
    for key in ("thumbnail", "browse", "preview"):
        asset = assets.get(key)
        if asset and asset.get("href"):
            return asset["href"]
    for key, asset in assets.items():
        href = (asset or {}).get("href", "")
        roles = (asset or {}).get("roles") or []
        if "thumbnail" in roles or "thumbnail" in key.lower() or href.lower().endswith(".png"):
            return href
    return None


def _load_and_buffer_roi(roi_shapefile, roi_coordinates, roi_buffer_km, temp_dir, log):
    """Lê o ROI (shapefile OU coordenadas) e aplica o pequeno buffer de contexto.
    Devolve (roi_gdf, roi_vector_path) - roi_gdf está na CRS original do ROI."""
    from shapely.geometry import Polygon

    have_shapefile = bool(roi_shapefile) and str(roi_shapefile).strip() != ""
    have_coords = roi_coordinates is not None and len(roi_coordinates) > 0

    if have_shapefile and have_coords:
        raise PipelineError("Fill in only ONE of ROI_SHAPEFILE or ROI_COORDINATES, and leave the other empty.")
    if not have_shapefile and not have_coords:
        raise PipelineError("Provide either ROI_SHAPEFILE or ROI_COORDINATES in the CONFIGURATION cell.")

    if have_shapefile:
        with _PROJ_LOCK:
            roi_gdf = gpd.read_file(roi_shapefile)
            if roi_gdf.crs is None:
                raise PipelineError("The ROI file has no CRS defined - please fix the input file.")
        roi_vector_path = roi_shapefile
        log(f"ROI input: shapefile ({roi_shapefile})")
    else:
        if len(roi_coordinates) < 3:
            raise PipelineError("ROI_COORDINATES needs at least 3 (lon, lat) vertices to form a polygon.")
        roi_polygon = Polygon(roi_coordinates)
        with _PROJ_LOCK:
            roi_gdf = gpd.GeoDataFrame({"id": [1]}, geometry=[roi_polygon], crs=4326)
            roi_vector_path = os.path.join(temp_dir, "roi_from_coordinates.gpkg")
            roi_gdf.to_file(roi_vector_path, driver="GPKG")
        log(f"ROI input: {len(roi_coordinates)} typed coordinate vertices (EPSG:4326)")

    roi_gdf = roi_gdf[roi_gdf.geometry.notnull() & roi_gdf.geometry.is_valid]
    if len(roi_gdf) == 0:
        raise PipelineError("The ROI has no valid, non-null geometries.")
    log(f"ROI loaded: {len(roi_gdf)} geometry(ies), CRS = {roi_gdf.crs}")

    # ---- ROI context buffer ----
    # Small expansion of the ROI so the delivered image shows a bit more context around the
    # requested coordinates - nothing more. This is the ONLY adjustment made to the ROI; the
    # processed extent is exactly this (small) buffered area. Clamped to [MIN_BUFFER_KM,
    # MAX_BUFFER_KM] so a mistaken/huge value can never trigger excessive processing.
    roi_buffer_km = _clamp_buffer_km(roi_buffer_km)

    if roi_buffer_km > 0:
        with _PROJ_LOCK:
            try:
                metric_crs = roi_gdf.estimate_utm_crs()
            except Exception:
                metric_crs = roi_gdf.to_crs(4326).estimate_utm_crs()
            roi_metric = roi_gdf.to_crs(metric_crs)
            _minx, _miny, _maxx, _maxy = roi_metric.total_bounds
            pad = roi_buffer_km * 1000.0
            roi_metric["geometry"] = box(_minx - pad, _miny - pad, _maxx + pad, _maxy + pad)
            roi_gdf = roi_metric.to_crs(roi_gdf.crs)
        roi_vector_path = os.path.join(temp_dir, "roi_buffered.gpkg")
        roi_gdf.to_file(roi_vector_path, driver="GPKG")
        log(f"ROI expanded by {roi_buffer_km:.3f} km for context (rectangular bounding box)")

    return roi_gdf, roi_vector_path


def search_available_scenes(params, log=print):
    """Busca no STAC do BDC as cenas CBERS-4A/WPM que intersectam o ROI dentro de
    uma janela de +/- `search_window_days` em torno de `target_date` (agora tratada
    como uma data APROXIMADA, não mais exata). Não levanta erro se nada for
    encontrado - devolve uma lista vazia, para que a interface possa sugerir ao
    usuário ampliar a janela ou escolher outra data, em vez de falhar direto.

    Devolve uma lista de dicts, ordenada pela proximidade com `target_date`:
        {id, tile, date, datetime, cloud_cover, thumbnail_url, item}
    Miniaturas NÃO são baixadas aqui (seriam N downloads por busca, a maioria
    descartada); a interface baixa sob demanda, uma por vez, ao selecionar uma
    linha - ver fetch_thumbnail_bytes() abaixo.
    `item` é o GeoJSON Feature STAC bruto (necessário depois em run_pipeline,
    via params["stac_items"], para pular a busca e processar exatamente a(s)
    cena(s) escolhida(s) pelo usuário)."""
    from shapely.geometry import shape as shapely_shape

    roi_shapefile = params.get("roi_shapefile")
    roi_coordinates = params.get("roi_coordinates")
    roi_buffer_km = params.get("roi_buffer_km", 2.0)
    target_date = params["target_date"]
    window_days = int(params.get("search_window_days", 60))

    temp_dir = tempfile.mkdtemp(prefix="cbers_wpm_search_")
    try:
        roi_gdf, _ = _load_and_buffer_roi(roi_shapefile, roi_coordinates, roi_buffer_km, temp_dir, log)
        with _PROJ_LOCK:
            roi_gdf_wgs84 = roi_gdf.to_crs(4326)
            roi_geoms_wgs84 = list(roi_gdf_wgs84.geometry.values)
            minx, miny, maxx, maxy = roi_gdf_wgs84.total_bounds
        log("ROI bounds (lon/lat):", (minx, miny, maxx, maxy))

        def roi_intersects(other_geom_wgs84):
            return any(other_geom_wgs84.intersects(g) for g in roi_geoms_wgs84)

        target_dt = datetime.strptime(target_date, "%Y-%m-%d")
        start = (target_dt - timedelta(days=window_days)).strftime("%Y-%m-%dT00:00:00Z")
        end   = (target_dt + timedelta(days=window_days)).strftime("%Y-%m-%dT23:59:59Z")

        search_url = STAC_URL.rstrip('/') + '/search'
        query = {
            "collections": COLLECTION,
            "datetime": f"{start}/{end}",
            "bbox": f"{minx},{miny},{maxx},{maxy}",
            "limit": 100,
        }
        log(f"Searching STAC for scenes within +/-{window_days} day(s) of {target_date}...")
        resp = requests.get(search_url, params=query, headers={"Accept": "application/json"}, timeout=60)
        resp.raise_for_status()
        feats = resp.json().get("features", [])
        feats = [f for f in feats if roi_intersects(shapely_shape(f["geometry"]))]
        log(f"Found {len(feats)} candidate scene(s) intersecting the ROI.")

        results = []
        for it in feats:
            date_str = _item_date_str(it)
            if date_str is None:
                continue
            tile = _extract_tile(it)
            item_dt = datetime.strptime(date_str, "%Y-%m-%d")
            entry = {
                "id": it["id"],
                "tile": tile,
                "date": date_str,
                "datetime": it["properties"].get("datetime"),
                "cloud_cover": it["properties"].get("eo:cloud_cover"),
                "days_from_target": abs((item_dt - target_dt).days),
                "thumbnail_url": _get_thumbnail_href(it),
                "item": it,
            }
            results.append(entry)

        results.sort(key=lambda e: (e["days_from_target"], e["tile"] or ""))
        return results
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def fetch_thumbnail_bytes(url, timeout=12):
    """Baixa uma única miniatura (PNG) sob demanda. Usada pela interface, em uma
    thread separada, só quando o usuário seleciona uma cena na lista - evita
    baixar N miniaturas de uma busca inteira quando só 1 ou 2 serão olhadas."""
    r = requests.get(url, timeout=timeout, headers={"Accept": "image/*"})
    r.raise_for_status()
    return r.content


def run_pipeline(params, log=print, should_cancel=None):
    """Executa o pipeline completo do CBERS-4A/WPM e retorna a lista de
    caminhos dos produtos finais gerados (RGB e NRGB).

    `params` é um dict com as mesmas opções da célula de CONFIGURATION do
    notebook (roi_shapefile, roi_coordinates, target_date, tclt_exe,
    final_output_dir, contrast_stretch, threads, cropped, output_crs,
    output_format, lossless, jp2_quality).
    `log` é chamado com uma única string de mensagem por vez.
    `should_cancel` é uma função sem argumentos que retorna True quando o
    usuário pediu cancelamento (normalmente QgsTask.isCanceled)."""

    if should_cancel is None:
        should_cancel = lambda: False

    _raw_log = log

    def log(*args):
        _raw_log(" ".join(str(a) for a in args))

    def _check_cancel():
        if should_cancel():
            raise PipelineCancelled("Processamento cancelado pelo usuário.")

    # ---- parâmetros vindos da interface (equivalentes à célula CONFIGURATION) ----
    ROI_SHAPEFILE     = params.get("roi_shapefile")
    ROI_COORDINATES   = params.get("roi_coordinates")
    ROI_BUFFER_KM     = params.get("roi_buffer_km", 2.0)
    TARGET_DATE       = params.get("target_date")
    STAC_ITEMS        = params.get("stac_items")   # cenas já escolhidas pelo usuário na interface (novo fluxo)
    TCLT_EXE          = params["tclt_exe"]
    FINAL_OUTPUT_DIR  = params["final_output_dir"]
    CONTRAST_STRETCH  = params.get("contrast_stretch", 600)
    THREADS           = params.get("threads", 10)
    OUTPUT_CRS        = params.get("output_crs")
    OUTPUT_FORMAT     = params.get("output_format", "JP2")
    LOSSLESS          = params.get("lossless", False)
    JP2_QUALITY       = params.get("jp2_quality", 100)
    GENERATE_RGB      = params.get("generate_rgb", True)
    GENERATE_NGB      = params.get("generate_ngb", False)

    # ---- internal settings (safe defaults - only touch if you know what you're doing) ----
    DATE_SEARCH_STEP_DAYS = 5     # legacy auto-search only: window widened by this many days on each retry
    DATE_SEARCH_MAX_DAYS  = 60    # legacy auto-search only: give up after +/- this many days

    if not STAC_ITEMS and not TARGET_DATE:
        raise PipelineError("Provide either stac_items (scenes selected in the UI) or target_date.")

    os.makedirs(FINAL_OUTPUT_DIR, exist_ok=True)
    TEMP_DIR = tempfile.mkdtemp(prefix="cbers_wpm_")
    log("Temporary working directory:", TEMP_DIR)

    try:

        # ====================== READ ROI (auto-detected: shapefile if given, else coordinates) ======================
        roi_gdf, ROI_VECTOR_PATH = _load_and_buffer_roi(
            ROI_SHAPEFILE, ROI_COORDINATES, ROI_BUFFER_KM, TEMP_DIR, log)

        with _PROJ_LOCK:
            roi_gdf_wgs84 = roi_gdf.to_crs(4326)
            roi_geoms_wgs84 = list(roi_gdf_wgs84.geometry.values)      # kept as a plain list - no union is ever computed
            minx, miny, maxx, maxy = roi_gdf_wgs84.total_bounds          # plain min/max, does not touch GEOS union
        log("ROI bounds (lon/lat):", (minx, miny, maxx, maxy))

        def roi_intersects(other_geom_wgs84):
            # True if other_geom_wgs84 intersects ANY of the ROI's individual geometries.
            # Uses each geometry's own .intersects() (a single GEOS predicate call) rather
            # than any vectorized "union_all"/"unary_union", which is broken on some
            # numpy/shapely version combinations.
            return any(other_geom_wgs84.intersects(g) for g in roi_geoms_wgs84)

        _roi_crs_cache = {}
        def roi_in_crs(target_crs):
            key = target_crs.to_string()
            if key not in _roi_crs_cache:
                with _PROJ_LOCK:
                    _roi_crs_cache[key] = roi_gdf.to_crs(target_crs)
            return _roi_crs_cache[key]

        from shapely.geometry import shape as shapely_shape

        extract_tile = _extract_tile

        if STAC_ITEMS:
            # ====================== SCENE(S) CHOSEN BY THE USER IN THE UI ======================
            # The user picked exact scene(s) from the results of search_available_scenes(), so no
            # date-window search/auto-selection happens here - we just validate and use them as-is.
            selected_items = {}
            for it in STAC_ITEMS:
                tile = extract_tile(it)
                if tile is None:
                    raise PipelineError(f"Could not extract a tile id from selected item '{it.get('id')}'.")
                if tile in selected_items and selected_items[tile]["id"] != it["id"]:
                    raise PipelineError(
                        f"Two different scenes were selected for the same tile ({tile}): "
                        f"'{selected_items[tile]['id']}' and '{it['id']}'. Select only one scene per tile.")
                selected_items[tile] = it

            not_intersecting = [
                tile for tile, it in selected_items.items()
                if not roi_intersects(shapely_shape(it["geometry"]))
            ]
            if not_intersecting:
                raise PipelineError(
                    "The following selected scene(s) do not intersect the ROI: " + ", ".join(not_intersecting))

            log("Using scene(s) selected by the user:")
            for tile, it in selected_items.items():
                log(f"  tile {tile}  ->  item '{it['id']}'  (date {it['properties'].get('datetime')})")
            if len(selected_items) > 1:
                log("NOTE: the ROI spans more than one tile; the bands from all tiles will be merged/mosaicked before processing.")

            _dates = sorted(_item_date_str(it) for it in selected_items.values() if _item_date_str(it))
            EFFECTIVE_DATE = _dates[0] if _dates else datetime.now().strftime("%Y-%m-%d")

        else:
            # ====================== LEGACY: STAC SEARCH BY BBOX + AUTOMATIC TILE SELECTION ======================
            # Kept for backward compatibility (e.g. calling run_pipeline() directly with only a
            # target_date, without going through the "search + pick" UI flow).
            def stac_search_by_bbox(stac_url, collection, bbox, target_date, step_days, max_days):
                search_url = stac_url.rstrip('/') + '/search'
                minx, miny, maxx, maxy = bbox
                target_dt = datetime.strptime(target_date, "%Y-%m-%d")
                window = step_days
                while window <= max_days:
                    start = (target_dt - timedelta(days=window)).strftime("%Y-%m-%dT00:00:00Z")
                    end   = (target_dt + timedelta(days=window)).strftime("%Y-%m-%dT23:59:59Z")
                    search_params = {
                        "collections": collection,
                        "datetime": f"{start}/{end}",
                        "bbox": f"{minx},{miny},{maxx},{maxy}",
                        "limit": 100,
                    }
                    resp = requests.get(search_url, params=search_params, headers={"Accept": "application/json"}, timeout=60)
                    resp.raise_for_status()
                    feats = resp.json().get("features", [])

                    feats = [f for f in feats if roi_intersects(shapely_shape(f["geometry"]))]

                    if feats:
                        return feats, window
                    log(f"  No images intersecting the ROI within +/-{window} days of {target_date}; widening search window...")
                    window += step_days
                raise PipelineError(f"No STAC items intersecting the ROI were found within +/-{max_days} days of {target_date}.")

            items, used_window = stac_search_by_bbox(STAC_URL, COLLECTION, (minx, miny, maxx, maxy),
                                                      TARGET_DATE, DATE_SEARCH_STEP_DAYS, DATE_SEARCH_MAX_DAYS)
            log(f"Found {len(items)} candidate STAC item(s) intersecting the ROI, within +/-{used_window} day(s) of {TARGET_DATE}.")

            def item_date(item):
                dt_str = item["properties"].get("datetime") or item["properties"].get("start_datetime")
                return datetime.strptime(dt_str[:10], "%Y-%m-%d")

            target_dt = datetime.strptime(TARGET_DATE, "%Y-%m-%d")
            best_by_tile = {}
            for it in items:
                tile = extract_tile(it)
                if tile is None:
                    continue
                diff = abs((item_date(it) - target_dt).days)
                if tile not in best_by_tile or diff < best_by_tile[tile][0]:
                    best_by_tile[tile] = (diff, it)

            if not best_by_tile:
                raise PipelineError("Could not extract a tile id from any of the returned STAC items.")

            selected_items = {tile: val[1] for tile, val in best_by_tile.items()}
            log("Tile(s) automatically selected because they intersect the ROI:")
            for tile, it in selected_items.items():
                log(f"  tile {tile}  ->  item '{it['id']}'  (date {it['properties'].get('datetime')})")
            if len(selected_items) > 1:
                log("NOTE: the ROI spans more than one tile; the bands from all tiles will be merged/mosaicked before processing.")

            EFFECTIVE_DATE = TARGET_DATE

        # ====================== ASSET / METADATA HELPERS (all in-memory, nothing saved) ======================
        def get_band_href(item, band_idx):
            assets = item.get("assets", {})
            for key in (f"BAND{band_idx}", f"band{band_idx}", f"Band{band_idx}"):
                if key in assets and "href" in assets[key]:
                    return assets[key]["href"]
            raise PipelineError(f"Asset BAND{band_idx} not found in item {item['id']}.")

        def get_xml_content(item):
            assets = item.get("assets", {})
            for key, asset in assets.items():
                if key.lower().endswith("xml") or key.lower() == "metadata":
                    href = asset.get("href")
                    if href:
                        r = requests.get(href, timeout=60)
                        if r.status_code == 200:
                            return r.text
            return None

        def get_elev_from_xml(xml_content):
            if not xml_content:
                return 90.0
            root = ET.fromstring(xml_content)
            image_elem = None
            for child in root:
                if 'image' in child.tag and 'imageMode' not in child.tag:
                    image_elem = child
                    break
            if image_elem is None:
                return 90.0
            for child in image_elem:
                if 'sunPosition' in child.tag:
                    return float(child[0].text)
            return 90.0

        def to_vsicurl(href):
            if href.startswith('/vsicurl/') or href.startswith('/vsis3/'):
                return href
            if href.startswith('http://') or href.startswith('https://'):
                return '/vsicurl/' + href
            return href

        # ====================== REMOTE CROP + MOSAIC (entirely in memory) ======================
        def crop_remote_band(href):
            vsi_path = to_vsicurl(href)
            with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR'):
                with rasterio.open(vsi_path) as src:
                    nodata = src.nodata if src.nodata is not None else 0
                    # Always crop to the (wide) processing ROI - the full scene is never
                    # downloaded/processed, only the requested area (+ safety/context margin).
                    roi_native = roi_in_crs(src.crs)
                    geoms = [mapping(g) for g in roi_native.geometry]
                    out_image, out_transform = rio_mask(src, geoms, crop=True, filled=False, all_touched=True)
                    profile = src.profile.copy()
                    profile.update(height=out_image.shape[1], width=out_image.shape[2],
                                    transform=out_transform, nodata=nodata)
            return out_image, profile

        def merge_band_crops(crops):
            if len(crops) == 1:
                arr, profile = crops[0]
                return np.asarray(arr.filled(profile['nodata']) if np.ma.isMaskedArray(arr) else arr), profile

            # Different CBERS tiles can ship in different local UTM zones. rasterio.merge()
            # requires every source to share one CRS, so reproject any tile that doesn't
            # match the first tile's CRS before mosaicking (this is what used to raise
            # "CRS mismatch with source" once the ROI got big enough to span two tiles).
            ref_crs = crops[0][1]['crs']

            mem_files, datasets = [], []
            try:
                for arr, profile in crops:
                    data = arr.filled(profile['nodata']) if np.ma.isMaskedArray(arr) else arr
                    if profile['crs'] != ref_crs:
                        dst_transform, dst_w, dst_h = calculate_default_transform(
                            profile['crs'], ref_crs, profile['width'], profile['height'],
                            *array_bounds(profile['height'], profile['width'], profile['transform']))
                        dst_profile = profile.copy()
                        dst_profile.update(crs=ref_crs, transform=dst_transform, width=dst_w, height=dst_h)
                        dst_data = np.zeros((data.shape[0], dst_h, dst_w), dtype=data.dtype)
                        reproject(
                            source=data, destination=dst_data,
                            src_transform=profile['transform'], src_crs=profile['crs'],
                            dst_transform=dst_transform, dst_crs=ref_crs,
                            src_nodata=profile['nodata'], dst_nodata=profile['nodata'],
                            resampling=Resampling.nearest)
                        data, profile = dst_data, dst_profile
                    mf = MemoryFile()
                    with mf.open(**profile) as ds:
                        ds.write(data)
                    mem_files.append(mf)
                    datasets.append(mf.open())
                merged_arr, merged_transform = rio_merge(datasets, nodata=datasets[0].nodata)
                ref_profile = datasets[0].profile.copy()
                ref_profile.update(height=merged_arr.shape[1], width=merged_arr.shape[2], transform=merged_transform)
                return merged_arr, ref_profile
            finally:
                for ds in datasets:
                    ds.close()
                for mf in mem_files:
                    mf.close()

        # ====================== FILL NODATA + SUN-ELEVATION CORRECTION + 0.75px SHIFT ======================
        scene_date_tag = EFFECTIVE_DATE.replace('-', '')
        tile_tag = "_".join(sorted(selected_items.keys()))
        SCENE_ID = f"CBERS_4A_WPM_{scene_date_tag}_{tile_tag}_L4"

        primary_item = next(iter(selected_items.values()))
        xml_content = get_xml_content(primary_item)
        elev = get_elev_from_xml(xml_content)
        azimuth = 90.0 - elev
        cos_azimuth = np.cos(np.radians(azimuth))
        log(f"Solar elevation: {elev:.2f} deg  ->  cos(azimuth) = {cos_azimuth:.4f}")

        def process_band(band_idx):
            crops = []
            for tile, item in selected_items.items():
                href = get_band_href(item, band_idx)
                log(f"  BAND{band_idx}: reading + cropping tile {tile} from STAC asset (network, in-memory)...")
                crops.append(crop_remote_band(href))

            band_arr, profile = merge_band_crops(crops)
            nodata = profile['nodata']

            valid_mask = (band_arr[0] != nodata).astype('uint8') * 255
            filled = fillnodata(band_arr[0].astype('float32'), mask=valid_mask,
                                 max_search_distance=1, smoothing_iterations=0)
            filled = (filled / cos_azimuth).astype('float32')

            t = profile['transform']
            shifted_transform = Affine(t.a, t.b, t.c - t.a * 0.75,
                                        t.d, t.e, t.f + t.a * 0.75)

            out_profile = profile.copy()
            out_profile.update(count=1, dtype='float32', transform=shifted_transform,
                                compress='lzw', nodata=nodata)

            out_path = os.path.join(TEMP_DIR, f"{SCENE_ID}_BAND{band_idx}_FD_Elev_Shift.tif")
            with rasterio.open(out_path, 'w', **out_profile) as dst:
                dst.write(filled, 1)

            del crops, band_arr, valid_mask, filled
            gc.collect()
            return out_path

        preprocessed_paths = {}
        for i in range(5):
            _check_cancel()
            log(f"Processing BAND{i}...")
            preprocessed_paths[f"BAND{i}"] = process_band(i)
        log("Pre-processed bands ready in the temp folder.")

        # ====================== GENERATE THE TCLT .txt PROJECT FILE ======================
        def to_uri(path):
            return "file://" + path.replace("\\\\", "/")

        def generate_tclt_txt(output_txt_path, preproc_files, roi_path, final_roi_path, analysis_name):
            # Every band is clipped to the (wide) processing ROI polygon before restoration -
            # processing the whole scene is no longer supported, only the ROI is ever produced.
            restore_src = {
                b: f"Clipped_by_polygons_imageB_{b}_vertice"
                for b in range(5)
            }

            clip_block = """
          VERTICE_START
            VERTICE_NAME "Clipped_by_polygons_imageB_4_vertice"
            VERTICE_TYPE "RASTERCLIPPING"
            VERTICE_CONNECTION "RASTER_B_4ToClip_vertice" "RASTER"
            VERTICE_CONNECTION "POLYGONS_vertice" "POLYGONS"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "Clipped_by_polygons_imageB_3_vertice"
            VERTICE_TYPE "RASTERCLIPPING"
            VERTICE_CONNECTION "RASTER_B_3ToClip_vertice" "RASTER"
            VERTICE_CONNECTION "POLYGONS_vertice" "POLYGONS"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "Clipped_by_polygons_imageB_2_vertice"
            VERTICE_TYPE "RASTERCLIPPING"
            VERTICE_CONNECTION "RASTER_B_2ToClip_vertice" "RASTER"
            VERTICE_CONNECTION "POLYGONS_vertice" "POLYGONS"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "Clipped_by_polygons_imageB_1_vertice"
            VERTICE_TYPE "RASTERCLIPPING"
            VERTICE_CONNECTION "RASTER_B_1ToClip_vertice" "RASTER"
            VERTICE_CONNECTION "POLYGONS_vertice" "POLYGONS"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "Clipped_by_polygons_imageB_0_vertice"
            VERTICE_TYPE "RASTERCLIPPING"
            VERTICE_CONNECTION "RASTER_B_0ToClip_vertice" "RASTER"
            VERTICE_CONNECTION "POLYGONS_vertice" "POLYGONS"
          VERTICE_END
        """

            content = f"""#Define arquivos imagem de entrada multiespectrais e Pancromatica
        CONTEXT_START
          CONTEXT_NAME "Context_Name_1"
          RESOURCE_URI "raster resource B_0" "{to_uri(preproc_files['BAND0'])}"
          RESOURCE_URI "raster resource B_1" "{to_uri(preproc_files['BAND1'])}"
          RESOURCE_URI "raster resource B_2" "{to_uri(preproc_files['BAND2'])}"
          RESOURCE_URI "raster resource B_3" "{to_uri(preproc_files['BAND3'])}"
          RESOURCE_URI "raster resource B_4" "{to_uri(preproc_files['BAND4'])}"
          RESOURCE_URI "vector resource 2" "{to_uri(roi_path)}"
          RESOURCE_URI "vector resource 3" "{to_uri(final_roi_path)}"
        CONTEXT_END

        GRAPH_START
          GRAPH_NAME "Graph_Name_1"

          VERTICE_START
            VERTICE_NAME "POLYGONS_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "vector resource 2" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "VECTOR_URI_IO_TYPE"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "POLYGONS_FINAL_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "vector resource 3" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "VECTOR_URI_IO_TYPE"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "RASTER_B_4ToClip_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "raster resource B_4" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "RASTER_URI_IO_TYPE"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "RASTER_B_3ToClip_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "raster resource B_3" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "RASTER_URI_IO_TYPE"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "RASTER_B_2ToClip_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "raster resource B_2" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "RASTER_URI_IO_TYPE"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "RASTER_B_1ToClip_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "raster resource B_1" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "RASTER_URI_IO_TYPE"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "RASTER_B_0ToClip_vertice"
            VERTICE_TYPE "URI"
            VERTICE_RESOURCE "raster resource B_0" "URI_ALIAS"
            VERTICE_PARAM "OUTPUT_TYPE" "RASTER_URI_IO_TYPE"
          VERTICE_END
        {clip_block}
          VERTICE_START
            VERTICE_NAME "restore_B4_vertice"
            VERTICE_TYPE "RASTER_RESTORATION"
            VERTICE_CONNECTION "{restore_src[4]}" "INPUT_RASTER"
            VERTICE_PARAM "SENSOR_TYPE" "CBERS_4_MUX"
            VERTICE_PARAM "SENSOR_BAND_DESIGNATIONS" "8"
            VERTICE_PARAM "RASTER_BANDS" "0"
            VERTICE_PARAM "SAMPLING_FACTOR" "SAMPLING_FACTOR_1_BY_2"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "restore_B3_vertice"
            VERTICE_TYPE "RASTER_RESTORATION"
            VERTICE_CONNECTION "{restore_src[3]}" "INPUT_RASTER"
            VERTICE_PARAM "SENSOR_TYPE" "CBERS_4_MUX"
            VERTICE_PARAM "SENSOR_BAND_DESIGNATIONS" "7"
            VERTICE_PARAM "RASTER_BANDS" "0"
            VERTICE_PARAM "SAMPLING_FACTOR" "SAMPLING_FACTOR_1_BY_2"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "restore_B2_vertice"
            VERTICE_TYPE "RASTER_RESTORATION"
            VERTICE_CONNECTION "{restore_src[2]}" "INPUT_RASTER"
            VERTICE_PARAM "SENSOR_TYPE" "CBERS_4_MUX"
            VERTICE_PARAM "SENSOR_BAND_DESIGNATIONS" "6"
            VERTICE_PARAM "RASTER_BANDS" "0"
            VERTICE_PARAM "SAMPLING_FACTOR" "SAMPLING_FACTOR_1_BY_2"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "restore_B1_vertice"
            VERTICE_TYPE "RASTER_RESTORATION"
            VERTICE_CONNECTION "{restore_src[1]}" "INPUT_RASTER"
            VERTICE_PARAM "SENSOR_TYPE" "CBERS_4_MUX"
            VERTICE_PARAM "SENSOR_BAND_DESIGNATIONS" "5"
            VERTICE_PARAM "RASTER_BANDS" "0"
            VERTICE_PARAM "SAMPLING_FACTOR" "SAMPLING_FACTOR_1_BY_2"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "restore_B0_vertice"
            VERTICE_TYPE "RASTER_RESTORATION"
            VERTICE_CONNECTION "{restore_src[0]}" "INPUT_RASTER"
            VERTICE_PARAM "SENSOR_TYPE" "CBERS2B_HRC"
            VERTICE_PARAM "SENSOR_BAND_DESIGNATIONS" "1"
            VERTICE_PARAM "RASTER_BANDS" "0"
            VERTICE_PARAM "SAMPLING_FACTOR" "SAMPLING_FACTOR_1_BY_2"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "TiePointsB4_Vertice"
            VERTICE_TYPE "TPLOCATOR"
            VERTICE_CONNECTION "restore_B0_vertice" "INPUT_1"
            VERTICE_CONNECTION "restore_B4_vertice" "INPUT_2"
            VERTICE_PARAM "EXEC_MODE" "1"
            VERTICE_PARAM "TP_LOC_ALGO" "MORAVEC"
            VERTICE_PARAM "BAND_1" "0"
            VERTICE_PARAM "BAND_2" "0"
            VERTICE_PARAM "MAX_TIE_POINTS" "1000"
            VERTICE_PARAM "PIXEL_SIZE_RELATION" "0"
            VERTICE_PARAM "TRANS_NAME" "Affine"
            VERTICE_PARAM "MAX_ERROR" "10"
            VERTICE_PARAM "MIN_TP_AREA_PERCENT" "2"
            VERTICE_PARAM "MIN_TP_NUMBER_FACTOR" "5"
            VERTICE_PARAM "ENABLE_SUBSAMPLE_OPT" "YES"
            VERTICE_PARAM "MORAVEC_CORR_WINDOW_W" "21"
            VERTICE_PARAM "MORAVEC_WINDOW_W" "21"
            VERTICE_PARAM "MORAVEC_FILTER_IT" "1"
            VERTICE_PARAM "MORAVEC_MIN_ABS_CORR" "0.15"
            VERTICE_PARAM "ENABLE_AUTO_REPROJ" "YES"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "RegisterB4_UsingAdjXY_Vertice"
            VERTICE_TYPE "REGISTER"
            VERTICE_CONNECTION "restore_B4_vertice" "INPUT_RASTER"
            VERTICE_CONNECTION "TiePointsB4_Vertice" "INPUT_TIE_POINTS"
            VERTICE_PARAM "OUT_SRID" "0"
            VERTICE_PARAM "OUT_RES_X" "2"
            VERTICE_PARAM "OUT_RES_Y" "2"
            VERTICE_PARAM "INTERP_METHOD" "BILINEAR_INTERP"
            VERTICE_PARAM "OUT_NO_DATA_VALUE" "-10000"
            VERTICE_PARAM "TRANS_NAME" "Affine"
            VERTICE_PARAM "TP_REF_SRID_PROP_NAME" "SRID_1"
            VERTICE_PARAM "TP_REF_X_PROP_NAME" "X_1"
            VERTICE_PARAM "TP_REF_Y_PROP_NAME" "Y_1"
            VERTICE_PARAM "TP_ADJ_SRID_PROP_NAME" "SRID_2"
            VERTICE_PARAM "TP_ADJ_X_PROP_NAME" "X_2"
            VERTICE_PARAM "TP_ADJ_Y_PROP_NAME" "Y_2"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "RegisterB3_UsingAdjXY_Vertice"
            VERTICE_TYPE "REGISTER"
            VERTICE_CONNECTION "restore_B3_vertice" "INPUT_RASTER"
            VERTICE_CONNECTION "TiePointsB4_Vertice" "INPUT_TIE_POINTS"
            VERTICE_PARAM "OUT_SRID" "0"
            VERTICE_PARAM "OUT_RES_X" "2"
            VERTICE_PARAM "OUT_RES_Y" "2"
            VERTICE_PARAM "INTERP_METHOD" "BILINEAR_INTERP"
            VERTICE_PARAM "OUT_NO_DATA_VALUE" "-10000"
            VERTICE_PARAM "TRANS_NAME" "Affine"
            VERTICE_PARAM "TP_REF_SRID_PROP_NAME" "SRID_1"
            VERTICE_PARAM "TP_REF_X_PROP_NAME" "X_1"
            VERTICE_PARAM "TP_REF_Y_PROP_NAME" "Y_1"
            VERTICE_PARAM "TP_ADJ_SRID_PROP_NAME" "SRID_2"
            VERTICE_PARAM "TP_ADJ_X_PROP_NAME" "X_2"
            VERTICE_PARAM "TP_ADJ_Y_PROP_NAME" "Y_2"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "TiePointsB2_Vertice"
            VERTICE_TYPE "TPLOCATOR"
            VERTICE_CONNECTION "restore_B0_vertice" "INPUT_1"
            VERTICE_CONNECTION "restore_B2_vertice" "INPUT_2"
            VERTICE_PARAM "EXEC_MODE" "1"
            VERTICE_PARAM "TP_LOC_ALGO" "MORAVEC"
            VERTICE_PARAM "BAND_1" "0"
            VERTICE_PARAM "BAND_2" "0"
            VERTICE_PARAM "MAX_TIE_POINTS" "1000"
            VERTICE_PARAM "PIXEL_SIZE_RELATION" "0"
            VERTICE_PARAM "TRANS_NAME" "Affine"
            VERTICE_PARAM "MAX_ERROR" "10"
            VERTICE_PARAM "MIN_TP_AREA_PERCENT" "2"
            VERTICE_PARAM "MIN_TP_NUMBER_FACTOR" "5"
            VERTICE_PARAM "ENABLE_SUBSAMPLE_OPT" "YES"
            VERTICE_PARAM "MORAVEC_CORR_WINDOW_W" "21"
            VERTICE_PARAM "MORAVEC_WINDOW_W" "21"
            VERTICE_PARAM "MORAVEC_FILTER_IT" "1"
            VERTICE_PARAM "MORAVEC_MIN_ABS_CORR" "0.15"
            VERTICE_PARAM "ENABLE_AUTO_REPROJ" "YES"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "RegisterB2_UsingAdjXY_Vertice"
            VERTICE_TYPE "REGISTER"
            VERTICE_CONNECTION "restore_B2_vertice" "INPUT_RASTER"
            VERTICE_CONNECTION "TiePointsB2_Vertice" "INPUT_TIE_POINTS"
            VERTICE_PARAM "OUT_SRID" "0"
            VERTICE_PARAM "OUT_RES_X" "2"
            VERTICE_PARAM "OUT_RES_Y" "2"
            VERTICE_PARAM "INTERP_METHOD" "BILINEAR_INTERP"
            VERTICE_PARAM "OUT_NO_DATA_VALUE" "-10000"
            VERTICE_PARAM "TRANS_NAME" "Affine"
            VERTICE_PARAM "TP_REF_SRID_PROP_NAME" "SRID_1"
            VERTICE_PARAM "TP_REF_X_PROP_NAME" "X_1"
            VERTICE_PARAM "TP_REF_Y_PROP_NAME" "Y_1"
            VERTICE_PARAM "TP_ADJ_SRID_PROP_NAME" "SRID_2"
            VERTICE_PARAM "TP_ADJ_X_PROP_NAME" "X_2"
            VERTICE_PARAM "TP_ADJ_Y_PROP_NAME" "Y_2"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "RegisterB1_UsingAdjXY_Vertice"
            VERTICE_TYPE "REGISTER"
            VERTICE_CONNECTION "restore_B1_vertice" "INPUT_RASTER"
            VERTICE_CONNECTION "TiePointsB4_Vertice" "INPUT_TIE_POINTS"
            VERTICE_PARAM "OUT_SRID" "0"
            VERTICE_PARAM "OUT_RES_X" "2"
            VERTICE_PARAM "OUT_RES_Y" "2"
            VERTICE_PARAM "INTERP_METHOD" "BILINEAR_INTERP"
            VERTICE_PARAM "OUT_NO_DATA_VALUE" "-10000"
            VERTICE_PARAM "TRANS_NAME" "Affine"
            VERTICE_PARAM "TP_REF_SRID_PROP_NAME" "SRID_1"
            VERTICE_PARAM "TP_REF_X_PROP_NAME" "X_1"
            VERTICE_PARAM "TP_REF_Y_PROP_NAME" "Y_1"
            VERTICE_PARAM "TP_ADJ_SRID_PROP_NAME" "SRID_2"
            VERTICE_PARAM "TP_ADJ_X_PROP_NAME" "X_2"
            VERTICE_PARAM "TP_ADJ_Y_PROP_NAME" "Y_2"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "Recomposed_registeredimage_vertice"
            VERTICE_TYPE "RECOMPOSE"
            VERTICE_CONNECTION "RegisterB4_UsingAdjXY_Vertice" "INPUT_RASTER_1"
            VERTICE_CONNECTION "RegisterB3_UsingAdjXY_Vertice" "INPUT_RASTER_2"
            VERTICE_CONNECTION "RegisterB2_UsingAdjXY_Vertice" "INPUT_RASTER_3"
            VERTICE_CONNECTION "RegisterB1_UsingAdjXY_Vertice" "INPUT_RASTER_4"
            VERTICE_PARAM "BANDS_STRING" "INPUT_RASTER_1:0 INPUT_RASTER_2:0 INPUT_RASTER_3:0 INPUT_RASTER_4:0"
            VERTICE_PARAM "VIRTUAL" "NO"
            VERTICE_PARAM "ALLOW_NO_DATA_PIXELS" "NO"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "PC2_vertice"
            VERTICE_TYPE "ARITHMETIC"
            VERTICE_CONNECTION "Recomposed_registeredimage_vertice" "INPUT_RASTER_1"
            VERTICE_PARAM "ARITHMETIC_STRING" "( INPUT_RASTER_1:0 * (-0.8196) + INPUT_RASTER_1:1 * 0.3306 + INPUT_RASTER_1:2 * 0.2653 + INPUT_RASTER_1:3 * 0.3854 )"
            VERTICE_PARAM "NORMALIZE_OUTPUT" "NO"
            VERTICE_PARAM "INTERP_METHOD" "NN_INTERP"
            VERTICE_PARAM "OUT_RST_DATA_TYPE" "FLOAT_TYPE"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "PC3_vertice"
            VERTICE_TYPE "ARITHMETIC"
            VERTICE_CONNECTION "Recomposed_registeredimage_vertice" "INPUT_RASTER_1"
            VERTICE_PARAM "ARITHMETIC_STRING" "( INPUT_RASTER_1:0 * 0.0783 - INPUT_RASTER_1:1 * 0.4005 - INPUT_RASTER_1:2 * 0.4294 + INPUT_RASTER_1:3 * 0.8057 )"
            VERTICE_PARAM "NORMALIZE_OUTPUT" "NO"
            VERTICE_PARAM "INTERP_METHOD" "NN_INTERP"
            VERTICE_PARAM "OUT_RST_DATA_TYPE" "FLOAT_TYPE"
          VERTICE_END
          VERTICE_START
            VERTICE_NAME "PC4_vertice"
            VERTICE_TYPE "ARITHMETIC"
            VERTICE_CONNECTION "Recomposed_registeredimage_vertice" "INPUT_RASTER_1"
            VERTICE_PARAM "ARITHMETIC_STRING" "( INPUT_RASTER_1:0 * (-0.0118) - INPUT_RASTER_1:1 * 0.6791 + INPUT_RASTER_1:2 * 0.7320 + INPUT_RASTER_1:3 * 0.0536 )"
            VERTICE_PARAM "NORMALIZE_OUTPUT" "NO"
            VERTICE_PARAM "INTERP_METHOD" "NN_INTERP"
            VERTICE_PARAM "OUT_RST_DATA_TYPE" "FLOAT_TYPE"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "Recomposed_PCSimage_vertice"
            VERTICE_TYPE "RECOMPOSE"
            VERTICE_CONNECTION "PC2_vertice" "INPUT_RASTER_1"
            VERTICE_CONNECTION "PC3_vertice" "INPUT_RASTER_2"
            VERTICE_CONNECTION "PC4_vertice" "INPUT_RASTER_3"
            VERTICE_PARAM "BANDS_STRING" "INPUT_RASTER_1:0 INPUT_RASTER_2:0 INPUT_RASTER_3:0"
            VERTICE_PARAM "VIRTUAL" "NO"
            VERTICE_PARAM "ALLOW_NO_DATA_PIXELS" "NO"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "NODATA_PCS_RASTER_VERTICE"
            VERTICE_TYPE "RASTERTRANSFORM"
            VERTICE_CONNECTION "Recomposed_PCSimage_vertice" "INPUT_RASTER"
            VERTICE_PARAM "BANDS_INDEXES" "0;1;2"
            VERTICE_PARAM "OPERATIONS" "NODATA_OP_TYPE"
            VERTICE_PARAM "OLD_NODATA_VALUE" "0"
            VERTICE_PARAM "NEW_NODATA_VALUE" "-10000"
            VERTICE_PARAM "UPDATE_PIXEL_VALUES" "NO"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "PanT2_vertice"
            VERTICE_TYPE "ARITHMETIC"
            VERTICE_CONNECTION "restore_B0_vertice" "INPUT_RASTER_1"
            VERTICE_PARAM "ARITHMETIC_STRING" "( INPUT_RASTER_1:0 * 2.0 )"
            VERTICE_PARAM "NORMALIZE_OUTPUT" "NO"
            VERTICE_PARAM "INTERP_METHOD" "NN_INTERP"
            VERTICE_PARAM "OUT_RST_DATA_TYPE" "FLOAT_TYPE"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "RESAMPLED_PCS_RES1M_BIL_VERTICE"
            VERTICE_TYPE "RASTERTRANSFORM"
            VERTICE_CONNECTION "NODATA_PCS_RASTER_VERTICE" "INPUT_RASTER"
            VERTICE_PARAM "BANDS_INDEXES" "0;1;2"
            VERTICE_PARAM "OPERATIONS" "RESAMPLE_OP_TYPE"
            VERTICE_PARAM "OUT_RES_X" "1"
            VERTICE_PARAM "OUT_RES_Y" "1"
            VERTICE_PARAM "INTERP_METHOD" "BILINEAR_INTERP"
            VERTICE_PARAM "UPDATE_PIXEL_VALUES" "YES"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "NODATA_RESAMPLED_VERTICE"
            VERTICE_TYPE "RASTERTRANSFORM"
            VERTICE_CONNECTION "RESAMPLED_PCS_RES1M_BIL_VERTICE" "INPUT_RASTER"
            VERTICE_PARAM "BANDS_INDEXES" "0;1;2"
            VERTICE_PARAM "OPERATIONS" "NODATA_OP_TYPE"
            VERTICE_PARAM "OLD_NODATA_VALUE" "0"
            VERTICE_PARAM "NEW_NODATA_VALUE" "-10000"
            VERTICE_PARAM "UPDATE_PIXEL_VALUES" "NO"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "Recomposed_PCAimage_vertice"
            VERTICE_TYPE "RECOMPOSE"
            VERTICE_CONNECTION "PanT2_vertice" "INPUT_RASTER_1"
            VERTICE_CONNECTION "NODATA_RESAMPLED_VERTICE" "INPUT_RASTER_2"
            VERTICE_PARAM "BANDS_STRING" "INPUT_RASTER_1:0 INPUT_RASTER_2:0 INPUT_RASTER_2:1 INPUT_RASTER_2:2"
            VERTICE_PARAM "VIRTUAL" "NO"
            VERTICE_PARAM "ALLOW_NO_DATA_PIXELS" "NO"
          VERTICE_END

          VERTICE_START
            VERTICE_NAME "NODATA_Recomposed_PCAimage_VERTICE"
            VERTICE_TYPE "RASTERTRANSFORM"
            VERTICE_CONNECTION "Recomposed_PCAimage_vertice" "INPUT_RASTER"
            VERTICE_PARAM "BANDS_INDEXES" "0;1;2;3"
            VERTICE_PARAM "OPERATIONS" "NODATA_OP_TYPE"
            VERTICE_PARAM "OLD_NODATA_VALUE" "0"
            VERTICE_PARAM "NEW_NODATA_VALUE" "-10000"
            VERTICE_PARAM "UPDATE_PIXEL_VALUES" "NO"
          VERTICE_END

        GRAPH_END

        PROJECT_START
          PROJECT_NAME "Proj_1"
          ANALYSIS "{analysis_name}" "Context_Name_1" "Graph_Name_1"
        PROJECT_END
        """
            with open(output_txt_path, 'w', encoding='utf-8') as f:
                f.write(content)

        project_txt = os.path.join(TEMP_DIR, "wpm_1m.txt")
        analysis_name = f"An_WPM_PCA_RGB321_{scene_date_tag}_{tile_tag}"
        generate_tclt_txt(project_txt, preprocessed_paths, ROI_VECTOR_PATH, ROI_VECTOR_PATH, analysis_name)
        log("TCLT project file generated at:", project_txt)

        # ====================== GENERATE + RUN THE .bat / tclt_exe ======================
        batch_file = os.path.join(TEMP_DIR, "wpm_1m.bat")
        log_file = os.path.join(TEMP_DIR, "ClipLog.txt")

        bat_content = f"""@echo off
        if exist "{log_file}" del "{log_file}"

        "{TCLT_EXE}" --threads_number={THREADS} --project_file_name="{project_txt}" --output_directory="{TEMP_DIR}" >> "{log_file}"
        set TCLT_ERRORLEVEL=%ERRORLEVEL%

        if %TCLT_ERRORLEVEL% == 0 goto :next
        echo "Errors encountered during execution.  Exited with status: %TCLT_ERRORLEVEL%"
        exit /b %TCLT_ERRORLEVEL%

        :next
        echo "Doing the next thing"
        exit /b 0
        """
        with open(batch_file, 'w', encoding='utf-8') as f:
            f.write(bat_content)

        _check_cancel()
        log("Running TCLT (this can take a while)...")
        result = subprocess.run(batch_file, shell=True, cwd=TEMP_DIR, capture_output=True, text=True)
        log(result.stdout)

        if result.returncode != 0:
            log("TCLT execution failed. Return code:", result.returncode)
            log("stderr:", result.stderr)
            if os.path.exists(log_file):
                log("Log contents:")
                with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
                    log(f.read())
            raise PipelineError("TCLT execution failed - see the log above. "
                                f"")

        log("TCLT finished successfully (process exit code 0).")

        # tclt_exe can return 0 even when individual graph vertices failed internally,
        # so the log itself has to be checked for per-vertice failures
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8', errors='replace') as lf:
                log_content = lf.read()
            fail_lines = [l for l in log_content.splitlines() if "Status:FAIL" in l]
            if fail_lines:
                log(f"TCLT reported {len(fail_lines)} vertice failure(s) - full log below:")
                log(log_content)
                raise PipelineError(
                    "TCLT failed on one or more graph vertices (see the full log above for the first "
                    "failure, which is the actual root cause - later failures are just downstream "
                    f"cascades).")

        _check_cancel()
        gc.collect()

        # ====================== COMPUTE NRGB / RGB IN PYTHON FROM THE PCA RASTER ======================
        # TCLT's ARITHMETIC vertices (B40/B30/B20/B10) that used to build NRGB from the PCA bands
        # crash inside TerraLib with an empty error message on some scenes, independent of ROI size.
        # NODATA_Recomposed_PCAimage_VERTICE (the PCA recompose) is reliable, so NRGB/RGB are now
        # derived from it here instead, using the same linear-combination coefficients and the same
        # SQUARE_ROOT + LINEAR contrast-stretch formulas the old graph used.
        pca_path = None
        for root, dirs, files in os.walk(TEMP_DIR):
            for f in files:
                if "NODATA_Recomposed_PCAimage_VERTICE".lower() in f.lower() and f.lower().endswith(('.tif', '.tiff')):
                    pca_path = os.path.join(root, f)
                    break
            if pca_path:
                break
        if pca_path is None:
            raise PipelineError("Could not locate the PCA raster (NODATA_Recomposed_PCAimage_VERTICE) "
                                 "that TCLT should have produced - check the log above.")

        with rasterio.open(pca_path) as src:
            pca = src.read().astype('float64')
            pca_nodata = src.nodata if src.nodata is not None else -10000.0
            pca_profile = src.profile.copy()

        b0, b1, b2, b3 = pca[0], pca[1], pca[2], pca[3]
        invalid = (pca[0] == pca_nodata) | np.isnan(pca[0])

        b40 = 0.5674 * b0 - 0.8196 * b1 + 0.0783 * b2 - 0.0118 * b3    # NIR
        b30 = 0.5187 * b0 + 0.3306 * b1 - 0.4005 * b2 - 0.6791 * b3    # Red
        b20 = 0.4577 * b0 + 0.2652 * b1 - 0.4294 * b2 + 0.7320 * b3    # Green
        b10 = 0.4466 * b0 + 0.3854 * b1 + 0.8057 * b2 + 0.05362 * b3   # Blue

        nrgb = np.stack([b40, b30, b20, b10])
        nrgb[:, invalid] = 0
        nrgb_int16 = np.clip(np.round(nrgb), -32768, 32767).astype('int16')

        def square_root_then_linear_stretch(band, sqrt_max):
            valid = ~invalid
            out = np.zeros_like(band, dtype='float64')
            clipped = np.clip(band, 0.0, sqrt_max)
            sqrt_stretched = 1.0 + (1023.0 - 1.0) * np.sqrt(clipped / sqrt_max)
            linear_clipped = np.clip(sqrt_stretched, 100.0, 1023.0)
            out = 1.0 + (255.0 - 1.0) * (linear_clipped - 100.0) / (1023.0 - 100.0)
            out[~valid] = 0.0
            return out

        rgb_uint8 = np.stack([
            square_root_then_linear_stretch(b30, float(CONTRAST_STRETCH)),
            square_root_then_linear_stretch(b20, float(CONTRAST_STRETCH)),
            square_root_then_linear_stretch(b10, float(CONTRAST_STRETCH)),
        ])
        rgb_uint8 = np.clip(np.round(rgb_uint8), 0, 255).astype('uint8')

        # crop both to the final (locked-to-minimum) ROI, same extent the old RASTERCLIPPING vertices produced
        with _PROJ_LOCK:
            final_roi_native = gpd.read_file(ROI_VECTOR_PATH).to_crs(pca_profile['crs'])
        final_geoms = [mapping(g) for g in final_roi_native.geometry]

        def crop_to_final_roi(arr, nodata_val):
            mem_profile = pca_profile.copy()
            mem_profile.update(count=arr.shape[0], dtype=arr.dtype, nodata=nodata_val)
            with MemoryFile() as mf:
                with mf.open(**mem_profile) as ds:
                    ds.write(arr)
                with mf.open() as ds:
                    cropped, cropped_transform = rio_mask(ds, final_geoms, crop=True, filled=True, all_touched=True, nodata=nodata_val)
            out_profile = mem_profile.copy()
            out_profile.update(height=cropped.shape[1], width=cropped.shape[2], transform=cropped_transform)
            return cropped, out_profile

        nrgb_cropped, nrgb_profile = crop_to_final_roi(nrgb_int16, 0)
        rgb_cropped, rgb_profile = crop_to_final_roi(rgb_uint8, 0)

        nrgb_tmp_path = os.path.join(TEMP_DIR, "computed_NRGB.tif")
        with rasterio.open(nrgb_tmp_path, 'w', **nrgb_profile) as dst:
            dst.write(nrgb_cropped)

        rgb_tmp_path = os.path.join(TEMP_DIR, f"computed_RGB_{CONTRAST_STRETCH}.tif")
        with rasterio.open(rgb_tmp_path, 'w', **rgb_profile) as dst:
            dst.write(rgb_cropped)

        del pca, nrgb, nrgb_int16, rgb_uint8, nrgb_cropped, rgb_cropped
        gc.collect()

        # ====================== COPY ONLY THE REQUESTED FINAL PRODUCTS ======================
        from rasterio.warp import calculate_default_transform, reproject, Resampling
        from rasterio.crs import CRS as RioCRS

        def to_uint8(data, nodata):
            out_bands = []
            for b in range(data.shape[0]):
                band = data[b].astype('float64')
                valid = (band != nodata) if nodata is not None else np.ones_like(band, dtype=bool)
                if valid.any() and band[valid].min() >= 0 and band[valid].max() <= 255:
                    out = np.clip(np.round(band), 0, 255).astype('uint8')
                else:
                    vmin, vmax = (band[valid].min(), band[valid].max()) if valid.any() else (0.0, 1.0)
                    if vmax > vmin:
                        scaled = (band - vmin) / (vmax - vmin) * 255.0
                    else:
                        scaled = np.zeros_like(band)
                    out = np.clip(np.round(scaled), 0, 255).astype('uint8')
                    log(f"  Note: band {b + 1} was linearly rescaled from [{vmin:.2f}, {vmax:.2f}] to [0, 255] for uint8 compression.")
                if nodata is not None:
                    out[~valid] = 0
                out_bands.append(out)
            return np.stack(out_bands)

        def to_int16(data, nodata):
            out_bands = []
            for b in range(data.shape[0]):
                band = data[b].astype('float64')
                valid = (band != nodata) if nodata is not None else np.ones_like(band, dtype=bool)
                out = np.clip(np.round(band), -32768, 32767).astype('int16')
                if nodata is not None:
                    out[~valid] = 0
                out_bands.append(out)
            return np.stack(out_bands)

        def parse_crs(value):
            return RioCRS.from_epsg(value) if isinstance(value, int) else RioCRS.from_string(value)

        def compress_final_product(src_path, dst_path, target_dtype='uint8'):
            with rasterio.open(src_path) as src:
                data = src.read()
                nodata = src.nodata
                arr = to_uint8(data, nodata) if target_dtype == 'uint8' else to_int16(data, nodata)
                profile = src.profile.copy()
                profile.update(dtype=target_dtype, nodata=0, count=arr.shape[0])
                del data
                gc.collect()

                if OUTPUT_CRS:
                    dst_crs = parse_crs(OUTPUT_CRS)
                    # IMPORTANT: pass the source pixel size explicitly. Without an
                    # explicit `resolution=`, calculate_default_transform() derives
                    # its own "optimal" output GSD from the raster's diagonal, which
                    # does NOT preserve the original 1 m spacing and typically rounds
                    # it up towards ~2 m — this was the cause of the plugin's outputs
                    # coming out at 2 m instead of 1 m whenever a target CRS was set.
                    src_res_x = abs(profile['transform'].a)
                    src_res_y = abs(profile['transform'].e)
                    transform, width, height = calculate_default_transform(
                        src.crs, dst_crs, profile['width'], profile['height'], *src.bounds,
                        resolution=(src_res_x, src_res_y))
                    reproj_arr = np.zeros((arr.shape[0], height, width), dtype=target_dtype)
                    for b in range(arr.shape[0]):
                        reproject(
                            source=arr[b], destination=reproj_arr[b],
                            src_transform=profile['transform'], src_crs=src.crs,
                            dst_transform=transform, dst_crs=dst_crs,
                            resampling=Resampling.nearest, src_nodata=0, dst_nodata=0)
                    del arr
                    arr = reproj_arr
                    profile.update(crs=dst_crs, transform=transform, width=width, height=height)

                profile.update(tiled=True, blockxsize=256, blockysize=256)

                if OUTPUT_FORMAT.upper() == "JP2":
                    profile['driver'] = 'JP2OpenJPEG'
                    if LOSSLESS:
                        profile.update(REVERSIBLE='YES', QUALITY=100)
                        label = 'JP2OpenJPEG (lossless, REVERSIBLE=YES)'
                    else:
                        profile.update(REVERSIBLE='NO', QUALITY=JP2_QUALITY)
                        label = f'JP2OpenJPEG (lossy, QUALITY={JP2_QUALITY})'
                    try:
                        with rasterio.open(dst_path, 'w', **profile) as dst:
                            dst.write(arr)
                        del arr
                        gc.collect()
                        return label, dst_path
                    except Exception as e:
                        log(f"  JP2OpenJPEG driver unavailable on this GDAL build ({e}); falling back to lossless GTiff/ZSTD.")

                profile['driver'] = 'GTiff'
                for k in ('REVERSIBLE', 'QUALITY'):
                    profile.pop(k, None)
                dst_path = os.path.splitext(dst_path)[0] + '.tif'
                zstd_profile = profile.copy()
                zstd_profile.update(compress='ZSTD', zstd_level=22, predictor=2, num_threads='ALL_CPUS')
                try:
                    with rasterio.open(dst_path, 'w', **zstd_profile) as dst:
                        dst.write(arr)
                    label = 'GTiff + ZSTD (level 22, lossless)'
                except Exception as e:
                    log(f"  ZSTD compression unavailable on this GDAL build ({e}); falling back to DEFLATE level 9.")
                    deflate_profile = profile.copy()
                    deflate_profile.update(compress='DEFLATE', zlevel=9, predictor=2)
                    with rasterio.open(dst_path, 'w', **deflate_profile) as dst:
                        dst.write(arr)
                    label = 'GTiff + DEFLATE (level 9, lossless)'
                del arr
                gc.collect()
                return label, dst_path

        out_ext = '.jp2' if OUTPUT_FORMAT.upper() == "JP2" else '.tif'
        desired_products = []
        if GENERATE_NGB:
            desired_products.append((nrgb_tmp_path, f"{SCENE_ID}_NRGB{out_ext}", 'int16'))
        if GENERATE_RGB:
            desired_products.append((rgb_tmp_path, f"{SCENE_ID}_RGB_{CONTRAST_STRETCH}_8bit{out_ext}", 'uint8'))
        if not desired_products:
            raise PipelineError("No product was selected (generate_rgb / generate_ngb are both False).")

        outputs = []
        for src, outname, dtype in desired_products:
            dst = os.path.join(FINAL_OUTPUT_DIR, outname)
            used, written_path = compress_final_product(src, dst, target_dtype=dtype)
            log(f"Final product written ({used}, dtype={dtype}): {written_path}")
            outputs.append(written_path)

        log(f"{len(outputs)} requested product(s) written to:", FINAL_OUTPUT_DIR)

        log("Final output folder now contains only the requested product(s):")
        for f in sorted(os.listdir(FINAL_OUTPUT_DIR)):
            log("  " + f)
        return outputs
    finally:
        shutil.rmtree(TEMP_DIR, ignore_errors=True)
        gc.collect()
        log("Temporary working directory removed: " + TEMP_DIR)

