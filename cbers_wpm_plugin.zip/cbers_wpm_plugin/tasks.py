# -*- coding: utf-8 -*-
# Created by Miguel Alexandre da Cunha
import os
import sys
import json
import queue
import shutil
import tempfile
import threading
import subprocess

from qgis.core import QgsTask
from qgis.PyQt.QtCore import pyqtSignal

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
RUNNER_SCRIPT = os.path.join(PLUGIN_DIR, "core", "subprocess_runner.py")


class _Cancelled(Exception):
    pass


def _make_json_safe(obj):
    """Remove/converte qualquer coisa que json.dump não aceite (ex.: bytes)
    antes de escrever os parâmetros para o processo filho."""
    if isinstance(obj, dict):
        return {k: _make_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_make_json_safe(v) for v in obj]
    if isinstance(obj, bytes):
        return None
    return obj


class _SubprocessRunnerMixin:
    """Roda o pipeline (busca ou processamento) em um PROCESSO Python
    separado e isolado do processo do QGIS - ver core/subprocess_runner.py
    para o motivo. Esta thread (a própria thread da QgsTask) só faz I/O:
    escreve os parâmetros em disco, inicia o processo filho, lê a saída dele
    linha a linha por uma thread auxiliar (encaminhando cada linha de log
    para a caixa de diálogo) e, no fim, lê o resultado em JSON."""

    def _run_in_subprocess(self, mode, params):
        work_dir = tempfile.mkdtemp(prefix="cbers_wpm_ipc_")
        params_path = os.path.join(work_dir, "params.json")
        result_path = os.path.join(work_dir, "result.json")

        try:
            with open(params_path, "w", encoding="utf-8") as f:
                json.dump(_make_json_safe(params), f)
        except (TypeError, ValueError) as exc:
            raise RuntimeError(
                "Falha ao serializar os parâmetros para o processo filho: {}".format(exc))

        creationflags = 0
        if os.name == "nt":
            creationflags = subprocess.CREATE_NO_WINDOW

        proc = subprocess.Popen(
            [sys.executable, RUNNER_SCRIPT, mode, params_path, result_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=creationflags,
        )
        self._proc = proc

        line_queue = queue.Queue()

        def _reader():
            try:
                for line in proc.stdout:
                    line_queue.put(line.rstrip("\n"))
            except Exception:
                pass
            finally:
                line_queue.put(None)  # sentinela: stdout fechado / processo terminou

        reader_thread = threading.Thread(target=_reader, daemon=True)
        reader_thread.start()

        try:
            while True:
                if self.isCanceled():
                    proc.terminate()
                    try:
                        proc.wait(timeout=5)
                    except Exception:
                        proc.kill()
                    raise _Cancelled()
                try:
                    line = line_queue.get(timeout=0.5)
                except queue.Empty:
                    continue
                if line is None:
                    break
                if line.startswith("LOG: "):
                    self._log(line[5:])
                elif line.strip():
                    # Qualquer outra saída do processo filho (ex.: um traceback
                    # que escapou do try/except do runner) - mostra mesmo assim,
                    # útil para diagnóstico.
                    self._log(line)

            proc.wait()
            reader_thread.join(timeout=5)
        finally:
            self._proc = None

        if not os.path.exists(result_path):
            raise RuntimeError(
                "O processo de {} terminou sem gerar resultado (código de saída {}). "
                "Verifique o log acima para a causa.".format(
                    "busca" if mode == "search" else "processamento", proc.returncode))

        with open(result_path, "r", encoding="utf-8") as f:
            result = json.load(f)

        shutil.rmtree(work_dir, ignore_errors=True)
        return result


class CbersWpmTask(QgsTask, _SubprocessRunnerMixin):
    """Executa run_pipeline() em um processo separado (ver
    core/subprocess_runner.py), encaminhando mensagens de log para a caixa
    de diálogo através de sinais."""

    messageLogged = pyqtSignal(str)

    def __init__(self, description, params):
        super().__init__(description, QgsTask.CanCancel)
        self.params = params
        self.exception = None
        self.error_message = None
        self.outputs = []
        self._proc = None

    def _log(self, *args):
        self.messageLogged.emit(" ".join(str(a) for a in args))

    def run(self):
        try:
            result = self._run_in_subprocess("process", self.params)
        except _Cancelled:
            self.error_message = "Processamento cancelado pelo usuário."
            return False
        except Exception as exc:  # noqa: BLE001 - queremos capturar qualquer erro inesperado
            import traceback
            self.exception = exc
            self.error_message = "Erro inesperado: {}\n\n{}".format(exc, traceback.format_exc())
            return False

        if not result.get("ok"):
            self.error_message = result.get("error") or "Erro desconhecido no processamento."
            return False

        self.outputs = result.get("outputs", [])
        return True

    def cancel(self):
        if self._proc is not None:
            try:
                self._proc.terminate()
            except Exception:
                pass
        super().cancel()

    def finished(self, result):
        # Chamado no thread principal quando a task termina.
        pass


class CbersWpmSearchTask(QgsTask, _SubprocessRunnerMixin):
    """Executa search_available_scenes() em um processo separado, para não
    travar a interface enquanto o STAC é consultado e as miniaturas (PNG)
    são baixadas - e para não arriscar derrubar o QGIS (ver
    core/subprocess_runner.py)."""

    messageLogged = pyqtSignal(str)

    def __init__(self, description, params):
        super().__init__(description, QgsTask.CanCancel)
        self.params = params
        self.exception = None
        self.error_message = None
        self.results = []
        self._proc = None

    def _log(self, *args):
        self.messageLogged.emit(" ".join(str(a) for a in args))

    def run(self):
        try:
            result = self._run_in_subprocess("search", self.params)
        except _Cancelled:
            self.error_message = "Busca cancelada pelo usuário."
            return False
        except Exception as exc:  # noqa: BLE001
            import traceback
            self.exception = exc
            self.error_message = "Erro inesperado: {}\n\n{}".format(exc, traceback.format_exc())
            return False

        if not result.get("ok"):
            self.error_message = result.get("error") or "Erro desconhecido na busca."
            return False

        self.results = result.get("results", [])
        return True

    def cancel(self):
        if self._proc is not None:
            try:
                self._proc.terminate()
            except Exception:
                pass
        super().cancel()

    def finished(self, result):
        pass
