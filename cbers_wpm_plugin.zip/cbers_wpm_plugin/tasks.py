# -*- coding: utf-8 -*-
from qgis.core import QgsTask
from qgis.PyQt.QtCore import pyqtSignal

from .core.pipeline import run_pipeline, PipelineError, PipelineCancelled


class CbersWpmTask(QgsTask):
    """Executa run_pipeline() em uma thread separada da interface do QGIS,
    encaminhando mensagens de log para a caixa de diálogo através de sinais."""

    messageLogged = pyqtSignal(str)

    def __init__(self, description, params):
        super().__init__(description, QgsTask.CanCancel)
        self.params = params
        self.exception = None
        self.error_message = None
        self.outputs = []

    def _log(self, msg):
        # Emitido de dentro da thread da task; o Qt enfileira a entrega no
        # thread principal automaticamente (conexão em fila) porque o slot
        # conectado roda no objeto criado no thread principal.
        self.messageLogged.emit(str(msg))

    def run(self):
        try:
            self.outputs = run_pipeline(
                self.params,
                log=self._log,
                should_cancel=self.isCanceled,
            )
            return True
        except PipelineCancelled as exc:
            self.error_message = str(exc)
            return False
        except PipelineError as exc:
            self.error_message = str(exc)
            return False
        except Exception as exc:  # noqa: BLE001 - queremos capturar qualquer erro inesperado
            import traceback
            self.exception = exc
            self.error_message = "Erro inesperado: {}\n\n{}".format(exc, traceback.format_exc())
            return False

    def finished(self, result):
        # Chamado no thread principal quando a task termina.
        pass
